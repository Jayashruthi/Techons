setDir  = fullfile('data');
imds = imageDatastore(setDir,'IncludeSubfolders',true,'LabelSource',...
    'foldernames');
[trainingSet,testSet] = splitEachLabel(imds,0.3,'randomize');
bag = bagOfFeatures(trainingSet);
categoryClassifier = trainImageCategoryClassifier(trainingSet,bag);
confMatrix = evaluate(categoryClassifier,testSet);
a=mean(diag(confMatrix));
[file path]=uigetfile('*.jpg');
z=strcat(path,file);
img = imread(z);
imshow(img);
[labelIdx, score] = predict(categoryClassifier,img);
s=categoryClassifier.Labels(labelIdx);
disp(s)
%disp(a)
TN=confMatrix(1);
FN=confMatrix(2);
FP=confMatrix(3);
TP=confMatrix(4);
Precision = TP / ( TP + FP );
Sensitivity = TP/( FN+ TP);
Specificity = TN/ ( TN+ FP);
%disp('precision');
%disp(Precision);
%disp('Sensitivity');
%disp(Sensitivity);
%disp('Specificity');
%disp(Specificity);
